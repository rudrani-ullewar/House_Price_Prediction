# House Price Prediction Using Machine Learning

## Project Overview
This project builds an end-to-end regression pipeline to estimate house sale prices from property characteristics. It demonstrates the Predictive Analytics / KDD stages: data understanding, cleaning, preprocessing, feature transformation, model training, evaluation, and interpretation.

## Problem Statement
Predict a house's sale price using available property characteristics such as area, rooms, quality, condition, and categorical attributes.

## Objective
Develop and compare machine-learning regression models for house-price estimation, evaluate them with standard regression metrics, and identify influential features.

## Dataset
**Recommended:** [Kaggle — House Prices: Advanced Regression Techniques](https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/data)

Download `train.csv` and place it at `dataset/train.csv`. The target column is `SalePrice`. Review the dataset terms before redistributing it.

**Alternative:** [Kaggle — USA Housing](https://www.kaggle.com/datasets/vedavyasv/usa-housing). If using this alternative, update `DATA_PATH` and `TARGET` in the notebook to match its columns.

## Methodology
Data Collection → Data Understanding → Data Cleaning → Exploratory Data Analysis → Preprocessing and Encoding → Train/Test Split → Model Development → Evaluation → Feature Interpretation → New-Property Prediction.

## Models
- Linear Regression
- Ridge Regression
- Random Forest Regressor
- Gradient Boosting Regressor

## Preprocessing
- Numeric missing values: median imputation
- Categorical missing values: most-frequent imputation
- Numeric features: standardization
- Categorical features: one-hot encoding
- Identifier column (such as `Id`) excluded where present

Preprocessing is fitted within a scikit-learn pipeline using the training split.

## Evaluation Metrics
- MAE (Mean Absolute Error)
- RMSE (Root Mean Squared Error)
- MAPE (Mean Absolute Percentage Error)
- R² (coefficient of determination)

## KDD Stages
1. Problem definition
2. Data selection
3. Data understanding and cleaning
4. Transformation
5. Model training
6. Evaluation
7. Interpretation and deployment discussion

## Project Structure
```text
House_Price_Prediction_ML_Project/
├── house_price_prediction.ipynb
├── dataset/
│   └── train.csv
├── README.md
├── requirements.txt
├── figures/
└── results/
```

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Download `train.csv` from the Kaggle dataset page.
3. Put it in the `dataset/` folder.
4. Open `house_price_prediction.ipynb` in Jupyter or Google Colab.
5. Confirm `DATA_PATH = Path("dataset/train.csv")` and `TARGET = "SalePrice"`.
6. Run all cells from top to bottom.

## Results
The notebook creates a model-comparison table and plots when executed. Do not report performance values until the notebook has been run with the dataset.

## Limitations
The dataset may not represent all housing markets or current prices. Estimates depend on data quality, feature coverage, and market conditions. This is an educational prototype, not a professional appraisal.
